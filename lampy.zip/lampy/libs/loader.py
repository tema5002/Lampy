libs = [
    "uselib"
    "run"
    "installpy"
    "loaderpy"
    "zxlib"
]