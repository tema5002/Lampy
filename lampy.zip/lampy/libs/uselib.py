import run

useliberror = "Cannot install lib (Reason: " + str(ImportError) + ')'
libs = [
    "run",
    "installpy",
    "loaderpy",
    "zxlib",
]


def install_lib(lib):
    if lib in libs:
        print(f'Installing {lib}')
        run.run_command(f'pip install {lib}')
    else:
        print(useliberror)