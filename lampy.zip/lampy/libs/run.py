def run_pyfile(pyfile):
    """
    Run a python file.
    """
    with open(pyfile, "r") as f:
        code = compile(f.read(), pyfile, "exec")
    exec(code)

def run_command(command):
    import os
    """
    Run a command.
    """
    os.system(command)