import os
import run
import webbrowser


if __name__ == "__main__":
    print('Installing libs...')

run.run_pyfile("libs/loader.py") # For loading the custom lib
run.run_pyfile("libs/uselib.py") # For loading the custom lib
run.run_pyfile("libs/run.py") # For installing the custom lib
run.run_command("pip install -r requirements.txt") # Installs libs
print('Upgrading pip....')
run.run_command("python -m pip install --upgrade pip") # Upgrades pip
print('Upgrading setuptools....')
run.run_command("python -m pip install --upgrade setuptools") # Upgrades setuptools
print('Copying files....')
run.run_command("cd started") # Copies files
run.run_command("cd copyfilesprogramminglanguage-main") # Copies files
print('Run readme.txt.')