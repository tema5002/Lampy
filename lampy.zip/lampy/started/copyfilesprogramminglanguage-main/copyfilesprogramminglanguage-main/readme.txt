Hey there! Welcome to my python lib! This is lampy. A python lib all coded by myself!!


To get started, create a python file and start off with "import lampy"
and enjoy!


List of all lampy extensions:
typing (Opens a typing image)
help (Shows this message)
emoji(emoji) (Prints any emoji's you want!)
github (See the copied files github repo (Yes, i used a github repo to download the files))
reverse (Reverse text)
discord(1, 2 or 3) (Choose between the main discord server, the new one or a special discord bot developement one)
notepad(text) (Open notepad with the specified text)
printall(dir) (Print all the files in a specified directory)


That's it for now!