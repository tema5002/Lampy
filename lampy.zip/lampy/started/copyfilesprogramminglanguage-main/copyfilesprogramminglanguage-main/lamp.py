import os

def extension(extension):
	os.system('ren extension') + extension + (' ext.lamp')